package com.pearl.v_ride_lib

object Global {
       var imageString: String = ""
       var CODE = 1
       var curr_lat: Double = 0.0
       var curr_long: Double = 0.0
}
