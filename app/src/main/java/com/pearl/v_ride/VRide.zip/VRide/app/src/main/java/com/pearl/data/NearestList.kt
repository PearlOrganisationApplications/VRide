package com.pearl.data

import android.icu.text.CaseMap.Title

data class NearestList(
    var place_name: String,
    var place_address: String,
)
