package com.pearl.data

data class TransactionList(
    var tTitle: String,
    var tAmount: String,
    var tDate: String,
    var tTime: String
)
