package com.pearl.data

data class HistoryList(
    var histroyImage: Int,
    var historyTitle: String,
    var historyDec: String,
    var historyDate: String,
    var historyTime: String
)
