package com.pearl.data

data class NotificationList(
    var nTitle: String,
    var nDescription: String
)
