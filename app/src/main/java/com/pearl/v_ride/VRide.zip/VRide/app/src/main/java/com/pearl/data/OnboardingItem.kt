package com.pearl.data

data class OnboardingItem (
    val onboardingImage: Int,
//    val onboardingImg: Int,
    val title: String,
    val discription: String
        )